### New Update
* Added 17 new mf classic keys (Hotels) (PR)
* OFW: Picopass/iClass plugin new UI
* OFW: NFC: On-device tag generator
* OFW: Add GPIO control through RPC
* OFW: Added Javacard Emulated mifare classic 1K compatibility
* OFW: other fixes
#### Previous changes
* Fixed picopass/iclass reader plugin build & included keys into plugin(from OFW PR)
* OFW: SubGhz keypad lock
* OFW: picopass/iclass reader plugin
* OFW: NFC emulation software tunning
* OFW: ToolChain versioning, better Windows support
* OFW: NFC: add Mifare Infineon
* OFW: some FBT fixes
* Merged latest ofw changes - scons build system
* Removed WAV Player - it's not bad as a concept but has a lot of problems
* Some small fixes
* Spectrum Analyzer - show current mode on screen when changing modes
* Spectrum Analyzer - Ultra Narrow mode
* Desktop autolock more time options
