# Flipper Application Manifests (.fam)

TBD