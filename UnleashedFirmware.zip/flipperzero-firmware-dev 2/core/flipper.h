#pragma once

void flipper_init();
