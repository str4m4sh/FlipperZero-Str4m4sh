#pragma once

void power_on_system_start();
