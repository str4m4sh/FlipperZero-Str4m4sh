#pragma once

typedef struct Nfc Nfc;
