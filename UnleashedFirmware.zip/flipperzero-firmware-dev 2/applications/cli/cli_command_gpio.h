#pragma once

#include "cli_i.h"

void cli_command_gpio(Cli* cli, string_t args, void* context);
