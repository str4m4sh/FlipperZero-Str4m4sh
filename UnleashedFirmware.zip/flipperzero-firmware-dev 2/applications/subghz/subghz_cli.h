#pragma once

#include <cli/cli.h>

void subghz_on_system_start();
